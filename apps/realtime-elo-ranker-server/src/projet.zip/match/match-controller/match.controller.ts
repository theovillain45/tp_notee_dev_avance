import { Controller, Post, Body } from '@nestjs/common';
import { MatchService } from '../match-service/match.service';
import { MatchResult } from '../interfaces/match.interface';
import { Player } from 'src/player/interfaces/player.interface';

@Controller('api/match')
export class MatchController {
  constructor(private readonly matchService: MatchService) {}

  @Post()
  async publishMatchResult(@Body() matchResult: MatchResult): Promise<Player[]> {
    console.log('Reçu depuis le client :', matchResult);
    return this.matchService.processMatchResult(matchResult);
  }
}
