import { Module } from '@nestjs/common';
import { MatchService } from './match-service/match.service';
import { PlayerModule } from '../player/player.module';
import { MatchController } from './match-controller/match.controller';

@Module({
  imports: [PlayerModule], // Importe PlayerModule pour accéder aux joueurs
  controllers: [MatchController],
  providers: [MatchService],
})
export class MatchModule {}