export interface MatchResult {
    winner: string | null; // ID du gagnant ou null si match nul
    loser: string | null; // ID du perdant ou null si match nul
    draw: boolean; // Indique si le match est un nul
  }