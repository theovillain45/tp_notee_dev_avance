import { Injectable } from '@nestjs/common';
import { PlayerService } from 'src/player/player-service/player.service';
import { MatchResult } from '../interfaces/match.interface';
import { Player } from 'src/player/interfaces/player.interface';

@Injectable()
export class MatchService {
  constructor(private readonly playerService: PlayerService) {}

  processMatchResult(matchResult: MatchResult): Player[] {
    // Gérer le cas où le match est nul
    if (matchResult.draw) {
      console.log('Match nul, aucun gagnant ni perdant à traiter.');
      return this.playerService.getPlayers(); // Retourne la liste des joueurs telle qu'elle est
    }
  
    // Rechercher les joueurs pour les cas gagnant/perdant
    const player1 = this.playerService.getPlayers().find(p => p.id === matchResult.winner);
    const player2 = this.playerService.getPlayers().find(p => p.id === matchResult.loser);
  
    if (!player1 || !player2) {
      throw new Error('One or both players not found');
    }
  
    const K = 32; // Facteur de pondération Elo
    const expectedScore1 = 1 / (1 + Math.pow(10, (player2.rank - player1.rank) / 400));
    const expectedScore2 = 1 / (1 + Math.pow(10, (player1.rank - player2.rank) / 400));
  
    // Calculer les nouveaux scores Elo
    player1.rank += Math.round(K * (1 - expectedScore1));
    player2.rank += Math.round(K * (0 - expectedScore2));
  
    return this.playerService.getPlayers(); // Retourne la liste mise à jour des joueurs
  }
}