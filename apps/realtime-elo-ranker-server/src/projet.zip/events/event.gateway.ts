import { Injectable } from '@nestjs/common';
import { EventEmitter2 } from 'eventemitter2';
import { Observable } from 'rxjs';

@Injectable()
export class EventGateway {
  private eventEmitter = new EventEmitter2();

  emitRankingUpdate(update: any) {
    this.eventEmitter.emit('rankingUpdate', update);
  }

  onRankingUpdate(): Observable<any> {
    return new Observable((subscriber) => {
      const listener = (update: any) => subscriber.next(update);
      this.eventEmitter.on('rankingUpdate', listener);

      return () => {
        this.eventEmitter.removeListener('rankingUpdate', listener);
      };
    });
  }
}
