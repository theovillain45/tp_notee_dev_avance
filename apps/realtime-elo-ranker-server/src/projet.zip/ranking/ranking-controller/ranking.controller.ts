import { Controller, Get, Sse } from '@nestjs/common';
import { RankingService } from '../ranking-service/ranking.service';
import { Observable } from 'rxjs';
import { RankingEvent } from '../interfaces/ranking-interface';

@Controller('api/ranking')
export class RankingController {
  constructor(private readonly rankingService: RankingService) {}

  @Get()
  async getRanking() {
    return this.rankingService.getRanking();
  }

  @Get('/events')
  @Sse()
  rankingUpdates(): Observable<any> {
    return this.rankingService.subscribeToRankingUpdates();
  }
}