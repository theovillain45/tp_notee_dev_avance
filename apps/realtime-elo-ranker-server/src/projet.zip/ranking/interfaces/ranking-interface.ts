export interface RankingEvent {
    timestamp: Date;
    updates: { playerId: string; newEloRating: number }[];
  }
  