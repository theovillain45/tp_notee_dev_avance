// src/ranking/ranking.service.ts
import { Injectable } from '@nestjs/common';
import { PlayerService } from 'src/player/player-service/player.service';
import { Player } from '../../player/interfaces/player.interface';
import { Observable } from 'rxjs';
import { RankingEvent } from '../interfaces/ranking-interface';
import { EventGateway } from '../../events/event.gateway';

@Injectable()
export class RankingService {
  constructor(
    private readonly playerService: PlayerService,
    private readonly eventGateway: EventGateway
  ) {}

  getRanking(): Player[] {
    // Obtenir les joueurs depuis PlayerService
    return this.playerService.getPlayers().sort((a, b) => b.rank - a.rank);
  }

  subscribeToRankingUpdates(): Observable<RankingEvent> {
    return this.eventGateway.onRankingUpdate();
  }

  publishRankingUpdate(update: RankingEvent) {
    this.eventGateway.emitRankingUpdate(update);
  }
}