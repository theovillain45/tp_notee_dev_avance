import { Controller, Post, Body } from '@nestjs/common';
import { PlayerService } from '../player-service/player.service';
import { PlayerDto } from '../dto/player.dto';

@Controller('api/player')
export class PlayerController {
  constructor(private readonly playerService: PlayerService) {}

  @Post()
  async createPlayer(@Body() playerDto: PlayerDto) {
    return this.playerService.createPlayer(playerDto);
  }
}