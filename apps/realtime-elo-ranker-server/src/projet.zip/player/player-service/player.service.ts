import { Injectable } from '@nestjs/common';
import { Player } from '../interfaces/player.interface';
import { PlayerDto } from '../dto/player.dto';

@Injectable()
export class PlayerService {
  private players: Player[] = [];

  createPlayer(playerDto: PlayerDto): Player {
    const player: Player = {
      id: playerDto.id,
      rank: playerDto.rank ?? this.calculateAverageElo(),
    };

    this.players.push(player);

    console.log('Joueur créé :', player);
    console.log('Liste des joueurs :', this.players);

    return player;
  }

  getPlayers(): Player[] {
    return this.players;
  }

  private calculateAverageElo(): number {
    if (this.players.length === 0) return 1000;
    const totalElo = this.players.reduce((sum, player) => sum + player.rank, 0);
    return totalElo / this.players.length;
  }
}
