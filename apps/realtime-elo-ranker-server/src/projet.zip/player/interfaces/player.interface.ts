export interface Player {
    id: string;
    rank: number;
  }