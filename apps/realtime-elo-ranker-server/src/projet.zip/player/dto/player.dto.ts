export class PlayerDto {
    id: string;
    rank?: number;
  }
  