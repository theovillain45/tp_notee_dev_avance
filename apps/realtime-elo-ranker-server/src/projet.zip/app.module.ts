import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
// import { PlayerController } from './player/player-controller/player.controller';
import { PlayerModule } from './player/player.module';
import { RankingController } from './ranking/ranking-controller/ranking.controller';
import { RankingModule } from './ranking/ranking.module';
import { PlayerController } from './player/player-controller/player.controller';
import { MatchModule } from './match/match.module';

@Module({
  imports: [PlayerModule, RankingModule, MatchModule],
  controllers: [AppController],
  providers: [AppService],

})
export class AppModule {}
